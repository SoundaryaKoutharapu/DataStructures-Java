public class AsciiArray
{
   public static void main(String[] args) 
   {
      int [] array = {68,98,121,66,89,78,72,66};
      for(int i=0;i<array.length;i++)
      {
          System.out.print((char)array[i] +" ");
      }
   }

}
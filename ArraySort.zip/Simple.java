public class Simple {
    public static void main(String args[]) {
        //System.out.println("Hello Soundarya");
        int marks=40;
        if(marks>=80)
        {
            System.out.println("merit");

        }
        else {
            System.out.println("slow student");
        }
    }
}
